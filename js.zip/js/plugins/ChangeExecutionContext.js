/*:
 * @plugindesc Changes the execution context between the next line executed inside an event routine.
 * @author Doommer
 *
 * @help Allow you to change to execution context between map events during event processing.
 * The following example, will change turn event 2's selfswitch A to ON, 
 * Event page excerpt from event 1:
 * | ...
 * | this.executeInContext(2, 1)
 * | Set selfswitch A = ON
 * | ...
 * 
 * If you need to execute a list of instruction wrap the in an indented code block:
 * | ...
 * | this.executeInContext(2);
 * | If : this._contextSwitched <-- to ensure context has been switch
 * |  Set selfswitch A = ON
 * |  Set selfswitch B = OFF
 * |  (... Add more lines as need)
 * | : End // return to starting indentation, so the next line will be in the original context (evnet 1).
 * | ...
 * 
 * Alternate, unsafe setup, with predetermined execution length:
 * | ...
 * | this.executeInContext(2, 3); <-- 3 = literal lines of instruction + 1
 * | Set selfswitch A = ON (2nd line)
 * | Set selfswitch B = OFF (3rd line)
 * | ... (4th line revert changes)
 */

var Imported = Imported || {};
Imported.Doommer_ChangeExecutionContext = true;

var Doommer = Doommer || {};
Doommer.EventContext = Doommer.EventContext || {};

Doommer.Parameters = PluginManager.parameters('ChangeExecutionContext');
Doommer.Param = Doommer.Param || {};

(function() {
    // Extend Game_Interpreter to add context switching functionality
    Game_Interpreter.prototype.executeInContext = function(targetEventId, evalLines) {
        if($gameMap.event(targetEventId)){
            this._originalEventId = this._eventId;
            this._eventId = targetEventId;
            this._originalIndent = this._indent; //This indicates when to revert the context
            this._contextSwitched = true;
            this._contextSwitchEval = evalLines || 2; //Default include next line
        }
    };

    // Override executeCommand to manage context switching
    Doommer_EventContext_Game_Interpreter_executeCommand = Game_Interpreter.prototype.executeCommand;
    Game_Interpreter.prototype.executeCommand = function() {
        // Process the command
        var result = Doommer_EventContext_Game_Interpreter_executeCommand.call(this);
        
        // Check if the context was switched and if the command processing has returned to the original indent
        if (this._contextSwitchEval <= 0 && this._contextSwitched && 
            (this._originalIndent === this._indent || this._list[this._index].code === 0 && this._originalIndent === this._indent-1)) {
            //Reset active state?
            //this._character.ExitEvent();
            // Reset to the original event context after execution ends
            this._eventId = this._originalEventId;
            this._contextSwitched = false;  // Clear the context switch flag
        }

        if(this._contextSwitchEval > 0){
            this._contextSwitchEval--;
        }

        return result;  // Continue processing the next command
    };
})();