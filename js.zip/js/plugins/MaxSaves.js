/*:
 * @plugindesc Change max number of save files
 * 
 * 
 * @param File Count
 * @desc Number of save files
 * @default 100
 * 
 * @help Change max number of save files
 */



  var parameters = PluginManager.parameters('MaxSaves');
  var fileCount = Number(parameters['File Count'] || 100);

DataManager.maxSavefiles = function() {
    return fileCount;
};