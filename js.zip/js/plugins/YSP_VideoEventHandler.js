/*:
 * @plugindesc Change the way ysp.VideoPlayer plugin handles videos from timing based to hmtlVideoElement event based.
 * @author Doommer
 *
 * @help This plugin listens to hmtlVideoElement raised event to detect when a video is ready for playback. It also includes a few new ways to terminate a video.
 * Commands:
 * ysp.VideoPlayer.loadVideo(string videoName): No longer needed before video playback. (Still recommended for user experience)
 * ysp.VideoPlayer.playVideoById(string videoId): Checkes event state before play. Use a normal.
 * ysp.VideoPlayer.continueOnEnd(string videoId, string videoName): Terminates and cleanes up the video once it has ended. Sets 'ysp.VideoPlayer.waitingForVideo = true', listen for change to false. Cancels looping.
 * ysp.VideoPlayer.freezeOnEnd(string videoId): Will freeze the video once it has ended. Sets 'ysp.VideoPlayer.waitingForVideo = true', listen for change to false. Cancels looping.
 */

(function() {
    // Check if ysp.VideoPlayer is defined
    if (!window.ysp || !ysp.VideoPlayer) {
        console.error("ysp.VideoPlayer is not defined. Cannot override loadVideo method.");
        return;
    }

    ysp.VideoPlayer.waitingForVideo = false;

    var originalYsploadVideo = ysp.VideoPlayer.loadVideo;
    ysp.VideoPlayer.loadVideo = (videoName) => {
        console.log("ysp.VideoPlayer load with fallback");

        let texture = originalYsploadVideo.call(ysp.VideoPlayer, videoName);

        texture.baseTexture.source.onsuspend = function() {
            console.log("Video has been suspended");
        }

        texture.baseTexture.source.onabort = function() {
            console.log("Video has aborted");
        }

        texture.baseTexture.source.onemptied = function() {
            console.log("Video has been emptied");
        }
        
        texture.baseTexture.source.onwaiting = function() {
            console.log("Video waiting");
            console.log(this);
            //Prevent interrupting looping animations
            if(!this.seeking){
                let currentTime = this.currentTime;
                this.load();
                this.oncanplaythrough = function(){
                    console.log("Freeze attempted resolved");
                    this.oncanplaythrough = null;
                    this.currentTime = currentTime;
                    this.play();
                }
            }
        }

        texture.baseTexture.source.onprogress = function() {
            console.log("Video progress");
        }

        texture.baseTexture.source.onpause = function() {
            console.log("Video paused");
        }

        texture.baseTexture.source.onloadstart = function() {
            console.log("Video begin load");
        }
        
        return texture;
    }

    var originalYspPlayVideo = ysp.VideoPlayer.playVideo;
    ysp.VideoPlayer.playVideo = function(video)
    {
        console.log("Adding video to spriteset");
        SceneManager._scene._spriteset.addVideo(video);

        if(video.texture.baseTexture.hasLoaded) {
            video.texture.baseTexture.source.play();
        } else {
            console.log("Waiting for video to load.");
            video.texture.baseTexture.source.oncanplaythrough = function() {
                console.log("Video ready to play!");
                this.oncanplaythrough = null;
                this.play();
            }
        }
    }

    var originalYspPlayVideoById = ysp.VideoPlayer.playVideoById;
    ysp.VideoPlayer.playVideoById = function(id)
    {
        let video = ysp.VideoPlayer.getVideoById(id);
        ysp.VideoPlayer.playVideo(video);
    }

    ysp.VideoPlayer.continueOnEnd = function (id, videoName) {
        let video = ysp.VideoPlayer.getVideoById(id);
        ysp.VideoPlayer.waitingForVideo = true;
        //Stop looping animation if applied.
        video.texture.baseTexture.source.loop = false;
        video.texture.baseTexture.source.onended = function() {
            ysp.VideoPlayer.stopVideoById(id);
            ysp.VideoPlayer.releaseVideo(videoName);
            ysp.VideoPlayer.waitingForVideo = false;
        }
    }

    ysp.VideoPlayer.freezeOnEnd = function (id) {
        let video = ysp.VideoPlayer.getVideoById(id);
        ysp.VideoPlayer.waitingForVideo = true;
        //Stop looping animation if applied.
        video.texture.baseTexture.source.loop = false;
        video.texture.baseTexture.source.onended = function() {
            this.pause();
            ysp.VideoPlayer.waitingForVideo = false;
        }
    }
})();