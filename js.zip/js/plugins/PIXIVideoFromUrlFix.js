/*:
 * @plugindesc Modifies the way PIXI loads videos from url. Removes an unnecessary call to .load().
 * @author Doommer
 *
 * @help Disable this plugin if you experience errors loading videos as Sprites.
 * There are no plugin commands or parameters for this plugin.
 */
(function() {
    var origPIXIFromUrl = PIXI.VideoBaseTexture.fromUrl;
    PIXI.VideoBaseTexture.fromUrl = function fromUrl(videoSrc, scaleMode) {
        var video = document.createElement('video');

        video.setAttribute('webkit-playsinline', '');
        video.setAttribute('playsinline', '');

        // array of objects or strings
        if (Array.isArray(videoSrc)) {
            for (var i = 0; i < videoSrc.length; ++i) {
                video.appendChild(createSource(videoSrc[i].src || videoSrc[i], videoSrc[i].mime));
            }
        }
        // single object or string
        else {
                video.appendChild(createSource(videoSrc.src || videoSrc, videoSrc.mime));
            }

        //video.load(); <-- This has been removed

        return PIXI.VideoBaseTexture.fromVideo(video, scaleMode);
    };

    function createSource(path, type) {
        if (!type) {
            type = 'video/' + path.substr(path.lastIndexOf('.') + 1);
        }
    
        var source = document.createElement('source');
    
        source.src = path;
        source.type = type;
    
        return source;
    }
})();