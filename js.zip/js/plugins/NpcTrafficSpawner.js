/*:
 * Version 1.8
 * Change log:
 * 1.3
 * Breaking changes:
 * - removed ConsistentSpawn from registerNpc() and registerNpcs(), as it did have any effect at that time.
 * Instead, override the global value in the npc spawn configuration page, if necessary.
 * Other changes:
 * - Added missing parameters to documentation.
 * - Changed ._lastExitUsed to ._previousEventUsedId, since the exit used should alwasys be the last event anyway.
 * - Added new npc parameter .moveAround, this is used to prevent npc choosing same event twice in a row.
 * - Fixed an error in logic prevent npc from realizing they have arrived at an event marked as "through" — making them idle indefinitely.
 * 1.4
 * Breaking changes:
 * - none
 * Other changes:
 * - Added support for ChangeExecutionContext plugin using 'asInteractingNpc()'
 *  - Npcs will now be registered with the event upon interacting with a 'use' type POI event,
 *    and can be manipulate with 'asInteractingNpc()'.
 * - Added 'Spawn safe zone' plugin parameter.
 * - Optimized the god aweful 'autoSpawnWeight' logic
 * - Added 'temporarilyDisableEvent()'
 * - Added general methods of 'GetClosest...'
 * 1.5
 * Breaking changes:
 * - none
 * Other changes:
 * - Parameterized 'exitPercentage' which determines the chance of an npc leaving the map, when selecting an new action.
 *  - Can be overridden per map.
 * - Added 'spawnAt(Id, x, y)' to forcibly spawn a npc at a given coordinate set.
 * - Fixed a check for verifying 'ChangeExecutionContext' has been imported. It now checks the correct variable.
 * 1.6
 * Breaking changes:
 * - none
 * Other changes:
 * - Added parameter 'Freeze on variable' with identical behavior to 'Freeze on event',
 *  except this will only activate when the $gameVariable, it listens to, evaluates to true.
 * - Added overload for 'spawnAt(Id, x, y)'.
 *  - To select a random npc from the registered list, pass the invalid id value -1 as the argument for Id.
 * - Fixed a check for verifying 'ChangeExecutionContext' has been imported. It now checks the correct variable.
 * 1.7
 * Breaking changes:
 * - none
 * Other changes:
 * - Added parameters 'Avoid obstacles' and 'Ignore other traffic' to influence pathfinding
 *   of the npcs.
 *  - Added a custom implementation for 'findDirectionTo' and 'isCollidedWithEvent'
 * - Added error handling for spawning traffic, when Galv.spawn fails to spawn.
 * 1.8
 * Breaking changes:
 * - none
 * Other changes:
 * - Reworked pathfinding algorithm 'isNextToWall()' and changed to static penalty rather than dynamic
 * 
 * @plugindesc Requires GALV_EventSpawner (Galv) and Smart Pathfinding (Shaz).
 * Optional functionality with YEP_EventChasePlayer (YanFly) and EventStayInArea, ChangeExecutionContext (Doommer) plugins
 * @author Doommer
 * 
 * @desc This script provides a simple way of populating the world with npc activity.
 * 
 * @help The first event page on npcs on the spawnMap should be a parallel run event,
 * used for initial configuration on spawn; General behavior, chase conditions etc.
 * After spawning is complete selfswitch 'A' will be set to true. Use that page for player interactions.
 * --------------------------------------/
 * Methods:
 * Setup actions:
 * - "use": Activates 'reservedSwitch' upon arrival, then "idle". (see below)
 * - "idle": Will stand inplace for X amount of frames before getting next task.
 * actionsParams=[waitMax:int:optional, waitMin:int:optional]
 * - "loiter": Require EventStayInArea.js. Will randomly wander X/Y distance around a given coordinate for max/min time.
 * actionsParams=[maxX:int, maxY:int:optional = maxX, maxTime:int:optional, minTime:int:optional]
 * 
 * Doommer.NpcTrafficSpawner.registerPointOfInterests(...[eventId:int, reservedSwitch:string:optional = 'A', action:string:optional = "idle", actionsParams:array[params:array]:optional = []])
 * Doommer.NpcTrafficSpawner.registerPointOfInterest(eventId:int, reservedSwitch:string:optional = 'A', action:string:optional = "idle", actionsParams:array[params:array]:optional = [])
 * Doommer.NpcTrafficSpawner.removePointOfInterests(...[eventId:int])
 * Doommer.NpcTrafficSpawner.removePointOfInterest(eventId:int)
 * 
 * Doommer.NpcTrafficSpawner.registerDespawners(...[eventId:int, reservedSwitch:string:optional = 'A', action:string:optional = "use"])
 * Doommer.NpcTrafficSpawner.registerDespawner(eventId:int, reservedSwitch:string:optional = 'A', action:string:optional = "use")
 * Doommer.NpcTrafficSpawner.removeDespawners(...[eventId:int])
 * Doommer.NpcTrafficSpawner.removeDespawner(eventId:int)
 * 
 * Doommer.NpcTrafficSpawner.registerSpawners(...[eventId:int, reservedSwitch:string:optional = 'A', spawnSequence:array[command:string, [params:array]]:optional = ["down"])
 * Doommer.NpcTrafficSpawner.registerSpawner(eventId:int, reservedSwitch:string:optional = 'A', spawnSequence:array[command:string, [params:array]]:optional = ["down"])
 * Doommer.NpcTrafficSpawner.removeSpawners(...[eventId:int])
 * Doommer.NpcTrafficSpawner.removeSpawner(eventId:int)
 * 
 * Doommer.NpcTrafficSpawner.registerNpcs(...[eventId:int, limit:int:optional = 1, autoSpawnWeight:int:optional = 1])
 * Doommer.NpcTrafficSpawner.registerNpc(eventId:int, limit:int:optional = 1, autoSpawnWeight:int:optional = 1) limit = -1 = infinite
 * Doommer.NpcTrafficSpawner.removeNpcs(...[eventId:int])
 * Doommer.NpcTrafficSpawner.removeNpc(eventId:int)
 * 
 * Spawning:
 * Doommer.NpcTrafficSpawner.spawn(eventId:int, entranceId:int:optional)
 * Doommer.NpcTrafficSpawner.spawnAt(eventId:int, x:int, y:int)
 * Doommer.NpcTrafficSpawner.getClosestSpawner = function (x:int,y:int,spwns:[Game_Event]:optional = undefined) returns Game_Event or undefined
 * Doommer.NpcTrafficSpawner.GetSpawnerClosestToPlayer() returns Game_Event or undefined
 * Doommer.NpcTrafficSpawner.GetSpawnerWithinDistance(x:int,y:int,limit:int,spwns:[Game_Event]:optional = undefined) returns [Game_Event]
 * 
 * Despawning:
 * Doommer.NpcTrafficSpawner.getClosestDespawner = function (x:int,y:int,dspwns:[Game_Event]:optional = undefined) returns Game_Event or undefined
 * Doommer.NpcTrafficSpawner.GetDespawnerClosestToPlayer() returns Game_Event or undefined
 * Doommer.NpcTrafficSpawner.GetDespawnerWithinDistance(x:int,y:int,limit:int,dspwns:[Game_Event]:optional = undefined) returns [Game_Event]
 * 
 * Points of Interest:
 * Doommer.NpcTrafficSpawner.getClosestPointOfInterest = function (x:int,y:int,pois:[Game_Event]:optional = undefined) returns Game_Event or undefined
 * Doommer.NpcTrafficSpawner.GetPointOfInterestClosestToPlayer() returns Game_Event or undefined
 * Doommer.NpcTrafficSpawner.GetPointOfInterestsWithinDistance(x:int,y:int,limit:int,pois:[Game_Event]:optional = undefined) returns [Game_Event]
 * 
 * 
 * Event control:
 * These method can be used to control event behavior once spawned — though they will act autonomously.
 * 
 * Doommer.NpcTrafficSpawner.chooseAction(event:Game_Event) Will choose and set the ._target for the event as a registered point of interest (75%) or exit (25%). 
 * Doommer.NpcTrafficSpawner.goToRandomPointOfInterest(event:Game_Event)
 * Doommer.NpcTrafficSpawner.goToPointOfInterest(event:Game_Event, pointId:int)
 * Doommer.NpcTrafficSpawner.goToRandomExit(event:Game_Event)
 * Doommer.NpcTrafficSpawner.goToExit(event:Game_Event, pointId:int)
 * 
 * Math:
 * Math.getRandomBetween(max:int, min:int:optional = 0) returns int
 * 
 * Enable auto-spawn:
 * Create a common event or an event per map need, and repeatedly call 'Doommer.NpcTrafficSpawner.autoSpawner(frequency:int=1,interval:int=undefined)'
 * to spawn npc from any registered spawner, while allowSpawn = true.
 * 
 * Create spawn map according to Galv.SPAWN instructions.
 * 
 * Npc on the spawn map should have custom configuration on the first event page. (as parallel)
 * After spawning the selfswitch 'A' will be set to true, to allow custom player interaction.
 * 
 * To configuration npc options use this in a script section 'let event = $gameMap.event(this._eventId);'
 * Followed by any of:
 * evnet.moveAround = true/false;
 * event._lookAtPlayer = true/false;
 * event._ignorePlayer = true/false;
 * event._freezeOnEvent = true/false;
 * event.consistentSpawn = true/false;
 * event._maxTimeBetweenActions = int;
 * event._minTimeBetweenActions = int;
 * 
 * --------------------------------------/
 * 
 * Potential additions:
 * Allow manual spawn on coordinated or registered events.
 * Exhaustive spawn cycle
 * Add more parameters (individual spawn cooldown etc.)
 * Group behavior
 * Assign or group event to specific npcs.
 * 
 * 
 * @param Max traffic
 * @type number
 * @min 0
 * @desc This determines the upperlimit for the
 * amount of traffic on the map at any given time.
 * @default 3
 * 
 * @param Search depth
 * @type number
 * @min 0
 * @desc This determines the amount of tiles
 * npcs will check before each moves. (Can be resource intensive)
 * @default 12
 * 
 * @param Max time between actions
 * @type number
 * @min 0
 * @desc This determines the maximum amount of
 * frames an npc must wait, before getting a new task
 * @default 400
 * 
 * @param Min time between actions
 * @type number
 * @min 0
 * @desc This determines the minimum amount of
 * frames an npc must wait, before getting a new task
 * @default 200
 * 
 * @param Min time between spawns
 * @type number
 * @min 0
 * @desc This determines the minimum amount of
 * frames must pass before a new npc can spawn
 * @default 400
 * 
 * @param Exit chance
 * @type number
 * @min 0
 * @max 100
 * @desc This determines the percentage chance
 * there is of any given npc leaving the map,
 * when choosing a new action.
 * @default 25
 * 
 * @param Look at player
 * @type boolean
 * @on YES
 * @off NO
 * @desc This determines whether traffic npcs
 * will turn to face the player when being
 * interacted with by the player.
 * @default false
 * 
 * @param Ignore player
 * @type boolean
 * @on YES
 * @off NO
 * @desc This determines whether traffic npcs
 * will ignore the player when pathing. (unaware behavior)
 * @default true
 * 
 * @param Freeze on event
 * @type boolean
 * @on YES
 * @off NO
 * @desc This determines whether traffic npcs
 * will freeze whenever an event is running.
 * @default true
 * 
 * @param Freeze on variable
 * @type number
 * @min 0
 * @desc This will freeze the npc when a variable
 * in the game state evaluates to true
 * @default 0
 * 
 * @param Unique spawns only
 * @type boolean
 * @on YES
 * @off NO
 * @desc This determines if multiple instances
 * of the same npc are allowed to spawn.
 * @default true
 * 
 * @param Consistent spawns
 * @type boolean
 * @on YES
 * @off NO
 * @desc This determines if npcs will enter 
 * from the same point they exit, if possible.
 * @default false
 * 
 * @param Move around
 * @type boolean
 * @on YES
 * @off NO
 * @desc This determines will cause the npcs to always
 * choose an action different from the previous one.
 * Resulting in them moving around the map more consistently.
 * @default false
 * 
 * @param Activity near player
 * @type boolean
 * @on YES
 * @off NO
 * @desc This will force the npcs to choose tasks
 * that are near the player's position.
 * @default false
 * 
 * @param Spawn near player
 * @type boolean
 * @on YES
 * @off NO
 * @desc This will force the npcs to spawn
 * near the player's position.
 * @default false
 * 
 * @param Spawn safe zone
 * @type number
 * @min 0
 * @desc The minimum number of tiles away from
 * the player, the npcs are allowed to spawn at. 
 * @default 0
 * 
 * @param Search limit
 * @type number
 * @min 0
 * @desc This determines the amount of tiles is
 * considered near the player when choosing activities.
 * @default 15
 * 
 * @param Avoid obstacles
 * @type boolean
 * @on YES
 * @off NO
 * @desc This will deter, but not prevent, the npcs from
 * walking next to an obstacle that is not the distination.
 * @default false
 * 
 * @param Ignore other traffic
 * @type boolean
 * @on YES
 * @off NO
 * @desc This will make npcs ignore other npcs not
 * immediately next to the npc when traveling.
 * @default false
 */

var Imported = Imported || {};
Imported.NpcTrafficSpawner = true;

var Doommer = Doommer || {};
Doommer.NpcTrafficSpawner = Doommer.NpcTrafficSpawner || {};

Doommer.Parameters = PluginManager.parameters('NpcTrafficSpawner');
Doommer.Param = Doommer.Param || {};

Doommer.Param.npcMaxTraffic = Number(Doommer.Parameters['Max traffic']);
Doommer.Param.npcMaxTimeBetweenActions = Number(Doommer.Parameters['Max time between actions']);
Doommer.Param.npcMinTimeBetweenActions = Number(Doommer.Parameters['Min time between actions']);
Doommer.Param.npcMaxTraffic = Number(Doommer.Parameters['Max traffic']);
Doommer.Param.npcSearchLimit = Number(Doommer.Parameters['Search depth']);
Doommer.Param.npcMinSpawnTime = Number(Doommer.Parameters['Min time between spawns']);
Doommer.Param.npcExitPercentage = Number(Doommer.Parameters['Exit chance']);
Doommer.Param.npcNearPlayerLimit = Number(Doommer.Parameters['Search limit']);
Doommer.Param.npcLookAtPlayer = String(Doommer.Parameters['Look at player']);
Doommer.Param.npcLookAtPlayer = eval(Doommer.Param.npcLookAtPlayer);
Doommer.Param.npcIgnorePlayer = String(Doommer.Parameters['Ignore player']);
Doommer.Param.npcIgnorePlayer = eval(Doommer.Param.npcIgnorePlayer);
Doommer.Param.npcFreezeOnEvent = String(Doommer.Parameters['Freeze on event']);
Doommer.Param.npcFreezeOnEvent = eval(Doommer.Param.npcFreezeOnEvent);
Doommer.Param.npcFreezeOnVariable = String(Doommer.Parameters['Freeze on variable']);
Doommer.Param.npcUniqueSpawns = String(Doommer.Parameters['Unique spawns only']);
Doommer.Param.npcUniqueSpawns = eval(Doommer.Param.npcUniqueSpawns);
Doommer.Param.npcUseConsistentSpawn = String(Doommer.Parameters['Consistent spawns']);
Doommer.Param.npcUseConsistentSpawn = eval(Doommer.Param.npcUseConsistentSpawn);
Doommer.Param.npcMoveAround = String(Doommer.Parameters['Move around']);
Doommer.Param.npcMoveAround = eval(Doommer.Param.npcMoveAround);
Doommer.Param.npcActivityNearPlayer = String(Doommer.Parameters['Activity near player']);
Doommer.Param.npcActivityNearPlayer = eval(Doommer.Param.npcActivityNearPlayer);
Doommer.Param.npcSpawnNearPlayer = String(Doommer.Parameters['Spawn near player']);
Doommer.Param.npcSpawnNearPlayer = eval(Doommer.Param.npcSpawnNearPlayer);
Doommer.Param.npcSpawnSafeZone = String(Doommer.Parameters['Spawn safe zone']);
Doommer.Param.npcSpawnSafeZone = eval(Doommer.Param.npcSpawnSafeZone);
Doommer.Param.npcAvoidObstacles = String(Doommer.Parameters['Avoid obstacles']);
Doommer.Param.npcAvoidObstacles = eval(Doommer.Param.npcAvoidObstacles);
Doommer.Param.npcIgnoreTraffic = String(Doommer.Parameters['Ignore other traffic']);
Doommer.Param.npcIgnoreTraffic = eval(Doommer.Param.npcIgnoreTraffic);


(function(){

    /* Setup */
    Doommer.NpcTrafficSpawner.registerNpcs = function name(...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            if(Array.isArray(eventIds[index])){
                Doommer.NpcTrafficSpawner.registerNpc(...eventIds[index]);
            } else {
                Doommer.NpcTrafficSpawner.registerNpc(eventIds[index]);
            }
        }
    }
    // limit = -1 to set infinite
    Doommer.NpcTrafficSpawner.registerNpc = function (eventId, limit = 1, autoSpawnWeight = 1) {
        let current = $gameMap.spawnedEvents().filter(se => se._spawnEventId == eventId).length;
        $gameMap._allowedNpcs[eventId] = {
            npcId: eventId,
            limit: limit,
            active: current,
            spawnCooldown: 0,
            useConsistentSpawn: Doommer.Param.npcUseConsistentSpawn,
            moveAround: Doommer.Param.npcMoveAround,
            autoSpawnWeight: autoSpawnWeight
        };
    }

    Doommer.NpcTrafficSpawner.removeNpcs = function (...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            Doommer.NpcTrafficSpawner.removeNpc(eventIds[index]);
        }
    }
    Doommer.NpcTrafficSpawner.removeNpc = function (eventId) {
        delete $gameMap._allowedNpcs[eventId];
    }

    Doommer.NpcTrafficSpawner.registerDespawners = function name(...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            if(Array.isArray(eventIds[index])){
                Doommer.NpcTrafficSpawner.registerDespawner(...eventIds[index]);
            } else {
                Doommer.NpcTrafficSpawner.registerDespawner(eventIds[index]);
            }
        }
    }

    Doommer.NpcTrafficSpawner.registerDespawner = function (eventId, reservedSwitch = 'A', action = "use") {
        let event = $gameMap.event(eventId);
        if(event === undefined){
            console.log("Cannot find event '" + eventId + "'.");
            return;
        }
        event._trafficInteract = reservedSwitch;
        event._actionType = action;
        $gameMap._despawners[eventId] = event;
    }

    Doommer.NpcTrafficSpawner.removeDespawners = function (...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            Doommer.NpcTrafficSpawner.removeDespawner(eventIds[index]);
        }
    }
    Doommer.NpcTrafficSpawner.removeDespawner = function (eventId) {
        delete $gameMap._despawners[eventId];
    }

    Doommer.NpcTrafficSpawner.registerSpawners = function (...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            if(Array.isArray(eventIds[index])){
                Doommer.NpcTrafficSpawner.registerSpawner(...eventIds[index]);
            } else {
                Doommer.NpcTrafficSpawner.registerSpawner(eventIds[index]);
            }
        }
    }
    Doommer.NpcTrafficSpawner.registerSpawner = function (eventId, reservedSwitch = 'A', spawnSequence = ["down"]) {
        let event = $gameMap.event(eventId);
        if(event === undefined){
            console.log("Cannot find event '" + eventId + "'.");
            return;
        }
        if(!Array.isArray(spawnSequence)) spawnSequence = [spawnSequence];
        event['onSpawnMove'] = Doommer.NpcTrafficSpawner.buildSpawnPattern(spawnSequence);
        event._trafficInteract = reservedSwitch;
        $gameMap._spawners[eventId] = event;
    }

    Doommer.NpcTrafficSpawner.removeSpawners = function (...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            Doommer.NpcTrafficSpawner.removeSpawner(eventIds[index]);
        }
    }
    Doommer.NpcTrafficSpawner.removeSpawner = function (eventId) {
        delete $gameMap._spawners[eventId];
    }
    
    Doommer.NpcTrafficSpawner.registerPointOfInterests = function (...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            if(Array.isArray(eventIds[index])){
                Doommer.NpcTrafficSpawner.registerPointOfInterest(...eventIds[index]);
            } else {
                Doommer.NpcTrafficSpawner.registerPointOfInterest(eventIds[index]);
            }
        }
    }
    Doommer.NpcTrafficSpawner.registerPointOfInterest = function (eventId, reservedSwitch = 'A', action = "idle", actionsParams = []) {
        let event = $gameMap.event(eventId);
        if(event === undefined){
            console.log("Cannot find event '" + eventId + "'.");
            return;
        }
        event._trafficInteract = reservedSwitch;
        event._actionType = action;
        event._config = actionsParams;
        $gameMap._pointsOfInterests[eventId] = event;
    }

    Doommer.NpcTrafficSpawner.removePointOfInterests = function (...eventIds) {
        for (let index = 0; index < eventIds.length; index++) {
            Doommer.NpcTrafficSpawner.removePointOfInterest(eventIds[index]);
        }
    }
    Doommer.NpcTrafficSpawner.removePointOfInterest = function (eventId) {
        delete $gameMap._pointsOfInterests[eventId];
    }

    /* Spawning */
    Doommer.NpcTrafficSpawner.spawn = function (eventId, entranceId) {
        if($gameMap.spawnedEvents().length >= $gameMap._npcLimit) {
            return;
        }
        
        if(Object.keys($gameMap._spawners).length > 0){
            let validSpawns = Object.values($gameMap._spawners).filter(spwn => spwn.visibleTo == undefined || spwn.visibleTo.some(id => id == eventId));
            const restrictedSet = new Set(Doommer.NpcTrafficSpawner.getEventsWithinDistance($gamePlayer.x, $gamePlayer.y, Doommer.Param.npcSpawnSafeZone, validSpawns));
            validSpawns = validSpawns.filter(spawn => !restrictedSet.has(spawn));
            
            let spawnCloset = $gameMap._spawners[entranceId];
            if(Doommer.Param.npcSpawnNearPlayer) {
                let spawners = Doommer.NpcTrafficSpawner.getSpawnersWithinDistance($gamePlayer.x, $gamePlayer.y, Doommer.Param.npcNearPlayerLimit, validSpawns);
                spawnCloset = spawnCloset || getRandomArrayEntry(spawners) || Doommer.NpcTrafficSpawner.getClosestSpawner($gamePlayer.x, $gamePlayer.y, validSpawns);
            } else {
                spawnCloset = spawnCloset || getRandomObjectEntry(validSpawns);
            }

            if(spawnCloset == undefined) {
                //Something went wrong
                console.log("No valid spawn for event: " + eventId);
                return;
            }
            
            spawnCloset.setSelfSwitch(spawnCloset._trafficInteract, true);
            let lastSpawn = $gameMap._lastSpawnEventId;
            Galv.SPAWN.event(eventId, spawnCloset.x, spawnCloset.y);
            let newEvent = $gameMap.event($gameMap._lastSpawnEventId);
            if(!newEvent) {
                return;
            }
            setupNewNpc(newEvent);
            newEvent._previousUsedEventId = spawnCloset._eventId;
            newEvent._getDirectiveOnMoveEnd = true;
            newEvent.forceMoveRoute(spawnCloset['onSpawnMove']);
        }
    }

    Doommer.NpcTrafficSpawner.spawnAt = function (eventId, x, y) {
        if(eventId === -1){
            const npc = Doommer.NpcTrafficSpawner.getRandomValidNpc();
            eventId = npc !== null ? npc.npcId : -1;
        }

        if(eventId <= 0) return;
        
        let lastSpawn = $gameMap._lastSpawnEventId;
        Galv.SPAWN.event(eventId, x, y);
        let newEvent = $gameMap.event($gameMap._lastSpawnEventId);
        if(!newEvent) {
            return;
        }
        setupNewNpc(newEvent);
        newEvent._actionTimer = 1;
        newEvent._getDirectiveOnTimerEnd = true;
    }

    function setupNewNpc(newEvent){
        if($gameMap._allowedNpcs[newEvent._spawnEventId]){
            $gameMap._allowedNpcs[newEvent._spawnEventId].active++;
            $gameMap._allowedNpcs[newEvent._spawnEventId].spawnCooldown = 250; //Global parameter?
        }

        if(Doommer.Param.npcAvoidObstacles) newEvent.findDirectionTo = customFindDirectionTo;
        newEvent._isTraffic = true;
        newEvent._ignoreTraffic = Doommer.Param.npcIgnoreTraffic;
        newEvent._isSpawning = true;
    }

    //Returns the closest event to a coordinate regardless of terrain and obstacles from a supplied list or all the events on the map.
    Doommer.NpcTrafficSpawner.getClosestEvent = function (x,y, evnts = undefined) {
        const events = evnts || $gameMap.events();
        let closestEvent = null;
        let minDistance = Infinity;

        Object.values(events).forEach(event => {
            const distance = Math.abs(event._x - x) + Math.abs(event._y - y);
            if (distance < minDistance) {
                minDistance = distance;
                closestEvent = event;
            }
        });

        return closestEvent;
    }
    
    //Returns the events within to a coordinate regardless of terrain and obstacles from a supplied list or all the events on the map.
    Doommer.NpcTrafficSpawner.getEventsWithinDistance = function (x,y,dist, evnts = undefined) {
        const events = evnts || $gameMap.events();
        let closestEvents = [];

        Object.values(events).forEach(event => {
            //Minus 1 to account for starting grid
            const distance = Math.abs(event._x - x) + Math.abs(event._y - y) - 1;
            if (distance < dist) {
                closestEvents.push(event);
            }
        });

        return closestEvents;
    }

    //Shortest distance regardless of terrain and obstacles.
    Doommer.NpcTrafficSpawner.getClosestSpawner = function (x,y, spwns = undefined) {
        const spawners = spwns || $gameMap._spawners;
        let closestSpawner = null;
        let minDistance = Infinity;

        Object.values(spawners).forEach(spawner => {
            const distance = Math.abs(spawner._x - x) + Math.abs(spawner._y - y);
            if (distance < minDistance) {
                minDistance = distance;
                closestSpawner = spawner;
            }
        });

        return closestSpawner;
    }

    Doommer.NpcTrafficSpawner.GetSpawnerClosestToPlayer = function () {
        const spawners = $gameMap._spawners;
        let closestSpawner = null;
        let minDistance = Infinity;

        Object.values(spawners).forEach(spawner => {
            const distance = Math.abs(spawner._x - $gamePlayer._x) + Math.abs(spawner._y - $gamePlayer._y);
            if (distance < minDistance) {
                minDistance = distance;
                closestSpawner = spawner;
            }
        });

        return closestSpawner;
    }

    Doommer.NpcTrafficSpawner.getSpawnersWithinDistance = function (x,y,dist, spwns = undefined) {
        const spawners = spwns || $gameMap._spawners;
        let closeSpawners = [];

        Object.values(spawners).forEach(spawner => {
            //Minus 1 to account for starting grid
            const distance = Math.abs(spawner._x - x) + Math.abs(spawner._y - y) - 1;
            if (distance < dist) {
                closeSpawners.push(spawner);
            }
        });

        return closeSpawners;
    }
    
    Doommer.NpcTrafficSpawner.GetXNearestSpawners = function (x,y,limit, spwns = undefined) {
        const spawners = spwns || $gameMap._spawners;
        let closeSpawners = [];

        Object.values(spawners).forEach(spawner => {
            // Calculate the Manhattan distance
            const distance = Math.abs(spawner._x - x) + Math.abs(spawner._y - y);
            spawner.distance = distance;
            closeSpawners.push(spawner);
        });

        // Sort the points of interest based on their distance
        closeSpawners.sort((a, b) => a.distance - b.distance);

        // Return only the closest points up to the specified limit
        return closeSpawners.slice(0, limit);
    }
    //Despawn
    Doommer.NpcTrafficSpawner.getClosestDespawner = function (x,y, dspwns = undefined) {
        const despawners = dspwns || $gameMap._despawners;
        let closestDespawner = null;
        let minDistance = Infinity;

        Object.values(despawners).forEach(despawner => {
            const distance = Math.abs(despawner._x - x) + Math.abs(despawner._y - y);
            if (distance < minDistance) {
                minDistance = distance;
                closestDespawner = despawner;
            }
        });

        return closestDespawner;
    }

    Doommer.NpcTrafficSpawner.GetDespawnerClosestToPlayer = function () {
        const despawners = $gameMap._despawners;
        let closestDespawner = null;
        let minDistance = Infinity;

        Object.values(despawners).forEach(despawner => {
            const distance = Math.abs(despawner._x - $gamePlayer._x) + Math.abs(despawner._y - $gamePlayer._y);
            if (distance < minDistance) {
                minDistance = distance;
                closestDespawner = despawner;
            }
        });

        return closestDespawner;
    }

    Doommer.NpcTrafficSpawner.GetDespawnersWithinDistance = function (x,y,dist, dspwns = undefined) {
        const despawners = dspwns || $gameMap._despawners;
        let closeDespawners = [];

        Object.values(despawners).forEach(despawner => {
            //Minus 1 to account for starting grid
            const distance = Math.abs(despawner._x - x) + Math.abs(despawner._y - y) - 1;
            if (distance < dist) {
                closeDespawners.push(despawner);
            }
        });

        return closeDespawners;
    }

    Doommer.NpcTrafficSpawner.GetXNearestDespawners = function (x,y,limit, dspwns = undefined) {
        const despawners = dspwns || $gameMap._despawners;
        let closeDespawners = [];

        Object.values(despawners).forEach(despawner => {
            // Calculate the Manhattan distance
            const distance = Math.abs(despawner._x - x) + Math.abs(despawner._y - y);
            despawner.distance = distance;
            closeDespawners.push(despawner);
        });

        // Sort the points of interest based on their distance
        closeDespawners.sort((a, b) => a.distance - b.distance);

        // Return only the closest points up to the specified limit
        return closeDespawners.slice(0, limit);
    }

    //Point of interest
    Doommer.NpcTrafficSpawner.getClosestPointOfInterest = function (x,y, pois = undefined) {
        const pointsOfInterests = pois || $gameMap._pointsOfInterests;
        let closestPointOfInterest = null;
        let minDistance = Infinity;

        Object.values(pointsOfInterests).forEach(pointOfInterest => {
            const distance = Math.abs(pointOfInterest._x - x) + Math.abs(pointOfInterest._y - y);
            if (distance < minDistance) {
                minDistance = distance;
                closestPointOfInterest = pointOfInterest;
            }
        });

        return closestPointOfInterest;
    }

    Doommer.NpcTrafficSpawner.GetPointOfInterestClosestToPlayer = function () {
        const pointsOfInterests = $gameMap._pointsOfInterests;
        let closestPointOfInterest = null;
        let minDistance = Infinity;

        Object.values(pointsOfInterests).forEach(pointOfInterest => {
            const distance = Math.abs(pointOfInterest._x - $gamePlayer._x) + Math.abs(pointOfInterest._y - $gamePlayer._y);
            if (distance < minDistance) {
                minDistance = distance;
                closestPointOfInterest = pointOfInterest;
            }
        });

        return closestPointOfInterest;
    }

    Doommer.NpcTrafficSpawner.GetPointOfInterestsWithinDistance = function (x,y,dist, pois = undefined) {
        const pointsOfInterests = pois || $gameMap._pointsOfInterests;
        let closestPointOfInterests = [];

        Object.values(pointsOfInterests).forEach(pointOfInterest => {
            //Minus 1 to account for starting grid
            const distance = Math.abs(pointOfInterest._x - x) + Math.abs(pointOfInterest._y - y) - 1;
            if (distance < dist) {
                closestPointOfInterests.push(pointOfInterest);
            }
        });

        return closestPointOfInterests;
    }

    Doommer.NpcTrafficSpawner.GetXNearestPointOfInterests = function (x,y,limit, pois = undefined) {
        const pointsOfInterests = pois || $gameMap._pointsOfInterests;
        let closestPointOfInterests = [];

        Object.values(pointsOfInterests).forEach(pointOfInterest => {
            // Calculate the Manhattan distance
            const distance = Math.abs(pointOfInterest._x - x) + Math.abs(pointOfInterest._y - y);
            pointOfInterest.distance = distance;
            closestPointOfInterests.push(pointOfInterest);
        });

        // Sort the points of interest based on their distance
        closestPointOfInterests.sort((a, b) => a.distance - b.distance);

        // Return only the closest points up to the specified limit
        return closestPointOfInterests.slice(0, limit);
    }
    
    Doommer_Game_Event_initMembers = Game_Event.prototype.initMembers;
    Game_Event.prototype.initMembers = function() {
        Doommer_Game_Event_initMembers.call(this);
        this._lookAtPlayer = Doommer.Param.npcLookAtPlayer;
        this._ignorePlayer = Doommer.Param.npcIgnorePlayer;
        this._freezeOnEvent = Doommer.Param.npcFreezeOnEvent;
        this._maxTimeBetweenActions = Doommer.Param.npcMaxTimeBetweenActions;
        this._minTimeBetweenActions = Doommer.Param.npcMinTimeBetweenActions;
        this._destinationObstructed = 0;
        this.useConsistentSpawn = Doommer.Param.npcUseConsistentSpawn;
        this.moveAround = Doommer.Param.npcMoveAround;
    };

    Doommer_Game_Event_setupPage = Game_Event.prototype.setupPage;
    Game_Event.prototype.setupPage = function() {
        Yanfly.ECP.Game_Event_setupPage.call(this);
        if(!this._isTraffic) {
            this.clearChaseSettings();
        }
    };

    Doommer.NpcTrafficSpawner.buildSpawnPattern = function (routePoints) {
        route = [];
        for (let index = 0; index < routePoints.length; index++) {
            let routePoint = null;
            if(Array.isArray(routePoints[index])){
                routePoint = getRouteMoniker(routePoints[index][0], routePoints[index][1]);
            } else {
                routePoint = getRouteMoniker(routePoints[index]);
            }
            route.push(routePoint);
        }
        route.push({ code: Game_Character.ROUTE_END });

        return moveRoute = {
            list: route,
            repeat: false,
            skippable: true,
            wait: false
        };
    }

    //Movements
    function getRouteMoniker(moniker, ...args) {
        switch (moniker) {
            case "up":
                return up();
            case "down":
                return down();
            case "left":
                return left();
            case "right":
                return right();
            case "wait":
                return wait(args[0]);
            default:
                return wait(1);
        }
    }

    function up() {
        return { code: Game_Character.ROUTE_MOVE_UP };
    }
    function down() {
        return { code: Game_Character.ROUTE_MOVE_DOWN };
    }
    function left() {
        return { code: Game_Character.ROUTE_MOVE_LEFT };
    }
    function right() {
        return { code: Game_Character.ROUTE_MOVE_RIGHT };
    }

    function wait(time) {
        return { code: Game_Character.ROUTE_WAIT, parameters: [time] };
    }

    Doommer_Game_Character_prototype_processRouteEnd = Game_Character.prototype.processRouteEnd;
    Game_Character.prototype.processRouteEnd = function() {
        Doommer_Game_Character_prototype_processRouteEnd.call(this);
        if(this._getDirectiveOnMoveEnd) {
            this._getDirectiveOnMoveEnd = false;
            this.setActionTimer(10);
        }
    };

    //Make traffic npcs ignore player position when moving
    Game_Character.prototype.ignorePlayerCollision = function(x, y) {
        return Game_Character.prototype.isCollidedWithCharacters.call(this, x, y);
    };

    Doommer_Game_Event_prototype_isCollidedWithCharacters = Game_Event.prototype.isCollidedWithCharacters;
    Game_Event.prototype.isCollidedWithCharacters = function(x, y) {
        if(this._isTraffic && this._ignorePlayer)
            return Game_Character.prototype.isCollidedWithCharacters.call(this, x, y);
        return Doommer_Game_Event_prototype_isCollidedWithCharacters.call(this, x, y);
    };
    
    Game_Event.prototype.isCollidedWithTraffic = function(x, y, excludeTraffic) {
        var events = $gameMap.eventsXyNt(x, y);

        if (excludeTraffic) events = events.filter(e => !e._isTraffic || e.isStopping() || this._moveSpeed > e._moveSpeed );

        return events.length > 0;
    };

    Doommer_Game_CharacterBase_prototype_isCollidedWithCharacters = Game_CharacterBase.prototype.isCollidedWithCharacters;
    Game_CharacterBase.prototype.isCollidedWithCharacters = function(x, y) {
        if(this._isTraffic && this._ignoreTraffic)
            return this.isCollidedWithTraffic(x, y, $gameMap.distance(this.x, this.y, x, y) > 1) || this.isCollidedWithVehicles(x, y);
        return Doommer_Game_CharacterBase_prototype_isCollidedWithCharacters.call(this, x, y)
    };

    //npc route planning
    Doommer.NpcTrafficSpawner.chooseAction = function (event) {
        event._leavingMap = false;
        let exitPercentage = $gameMap._npcExitPercentage;
        if(event._anchorCoord) {
            event.removeBoundary();
        }

        let enablePoi = Object.keys($gameMap._pointsOfInterests).length > 0;
        if(!enablePoi) {
            exitPercentage = 1;
        }

        if(Object.keys($gameMap._despawners).length > 0 && Math.random() < exitPercentage){
            event._leavingMap = true;
            Doommer.NpcTrafficSpawner.goToRandomExit(event);
        } else if (enablePoi) {
            Doommer.NpcTrafficSpawner.goToRandomPointOfInterest(event);
        } else {
            //retry
            console.log("No possible action found. Help!")
            event._getDirectiveOnTimerEnd = true;
            event._actionTimer = 10;
        }
    }

    Game_Event.prototype.setActionTimer = function (time) {
        this._actionTimer = time;
        this._getDirectiveOnTimerEnd = true;
    }
    Game_Event.prototype.setInteractionResetTimer = function (time) {
        this._resetInteractionTimer = time;
        this._resetInteraction = true;
    }

    Doommer.NpcTrafficSpawner.goToRandomPointOfInterest = function (event) {
        let randomInterest;
        let validInterests = event.getVisibleEvents($gameMap._pointsOfInterests);

        if(event.moveAround){
            validInterests = validInterests.filter(e => e._eventId != event._previousUsedEventId);
        }

        if(Doommer.Param.npcActivityNearPlayer){
            let nearestInterests = Doommer.NpcTrafficSpawner.GetPointOfInterestsWithinDistance($gamePlayer.x, $gamePlayer.y, Doommer.Param.npcNearPlayerLimit, validInterests);

            if(nearestInterests.length == 0) {
                randomInterest = Doommer.NpcTrafficSpawner.getClosestPointOfInterest($gamePlayer.x, $gamePlayer.y, validInterests);
            } else {
                randomInterest = getRandomArrayEntry(nearestInterests);
            }
        } else {
            randomInterest = getRandomObjectEntry(validInterests);
        }
         
        event.setTarget(randomInterest);
    }
    Doommer.NpcTrafficSpawner.goToPointOfInterest = function (event, pointId) {
        let Interest = $gameMap._pointsOfInterests[pointId];
        event.setTarget(Interest);
    }

    /* Despawning */
    Doommer.NpcTrafficSpawner.goToRandomExit = function (event) {
        let randomExit;
        let validExits = event.getVisibleEvents($gameMap._despawners);

        if(event.moveAround || event._isSpawning){
            validExits = validExits.filter(e => e._eventId != event._previousUsedEventId);
        }

        if(Doommer.Param.npcActivityNearPlayer){
            let nearestDespawners = Doommer.NpcTrafficSpawner.GetDespawnersWithinDistance($gamePlayer.x, $gamePlayer.y, Doommer.Param.npcNearPlayerLimit, validExits);
            if(nearestDespawners.length == 0) {
                randomExit = Doommer.NpcTrafficSpawner.getClosestDespawner($gamePlayer.x, $gamePlayer.y, validExits);
            } else {
                randomExit = getRandomArrayEntry(nearestDespawners);    
            }
        } else {
            randomExit = getRandomObjectEntry(validExits);
        }

        event.setTarget(randomExit);
    }
    Doommer.NpcTrafficSpawner.goToExit = function (event, exitId) {
        let exit = $gameMap._despawners[exitId];
        event.setTarget(exit);
    }

    Game_CharacterBase.prototype.useExit = function () {
        let npc = $gameMap._allowedNpcs[this._spawnEventId];
        npc.spawnCooldown += 250;
        npc.active--;
        npc._previousUsedEventId = this._target._eventId;
        this._erased = true;
        Galv.SPAWN.unspawn(this);
    }

    //Movements
    Doommer_ECP_Game_Event_updateSelfMovement = Game_Event.prototype.updateSelfMovement;
    Game_Event.prototype.updateSelfMovement = function() {
        Doommer_ECP_Game_Event_updateSelfMovement.call(this);
        if((this._freezeOnEvent && $gameMap._interpreter.isRunning())
        || $gameVariables.value([Doommer.Param.npcFreezeOnVariable])
        ) {
        return;
        }
        
        //Add event trigger on contact
        if (this._isTraffic && this._trigger === 2 && $gamePlayer.pos(this.x, this.y)) {
            if (!this.isJumping() && this.isNormalPriority()) {
                this.start();
            }
        }
    };

    Game_Interpreter.prototype.temporarilyDisableEvent = function(frames = 60){
        let evt = $gameMap.event(this._eventId);
        if(evt){
            evt.disableAutoActivation(frames);
        }
    }

    // Extending the Game_Event class to include chase cooldown functionality
    Game_Event.prototype.disableAutoActivation = function(frames = 60) {
        if(this._chasePlayer){
            this.endEventChase();
        }
        
        let origChaseRange = this._chaseRange; // Store original chase range
        let origTrigger = this._trigger;
        this._trigger = 0; // Temporarily disable activation
        this._chaseRange = 0; // Temporarily disable chasing (YanFly)
        this._eventDisabledTimer = frames; // Set the timer

        // Update function to handle the timer
        this._updateChaseCooldown = function() {
            if (--this._eventDisabledTimer <= 0) {
                if(this._chasePlayer){
                    this.endEventChase();
                }
                // Timer is up, reset chase range
                this._chaseRange = origChaseRange;
                this._trigger = origTrigger;
                // Clear the custom update function once the cooldown is over
                this._updateChaseCooldown = null;
            }
        };
    };

    //Search Depth per movement pass
    Doommer_Game_Character_prototype_searchLimit = Game_Character.prototype.searchLimit;
    Game_Character.prototype.searchLimit = function() {
        if(this._isTraffic){
            return Doommer.Param.npcSearchLimit;
        }
        return Doommer_Game_Character_prototype_searchLimit.call(this);
    };

    var Orig_Game_CharacterBase_updateStop = Game_CharacterBase.prototype.updateStop;
    Game_CharacterBase.prototype.updateStop = function() {
        if(this._isTraffic && (($gameMap._interpreter.isRunning() && this._freezeOnEvent)
            || $gameVariables.value([Doommer.Param.npcFreezeOnVariable]))){
            return
        }

        Orig_Game_CharacterBase_updateStop.call(this);

        if (this._updateChaseCooldown) {
            this._updateChaseCooldown();
        }

        if(this._target != null){
            if(this.adjecentToTarget()) {
                if(this._leavingMap){
                    this._target.setSelfSwitch(this._target._trafficInteract, true);
                    this._through = true;
                    this._chaseRange = 0; //Prevent wall clipping npc chase
                } else if(!this.isMoving()) {
                    this.arrivedAtDestination();
                }
            }
            if(this.isOnTarget()) {
                this.arrivedAtDestination();
            }

            this.updateTargetObstructedCounter();
        }
        
        if(this._isTraffic && !this._chasePlayer){
            if(this._actionTimer > 0 && --this._actionTimer === 0){
                if(this._originalMoveType){
                    //Reset movement type
                    this._moveType = this._originalMoveType;
                    this._originalMoveType = null;
                }
            } else if(this._getDirectiveOnTimerEnd && this._actionTimer <= 0) {
                this._getDirectiveOnTimerEnd = false;
                Doommer.NpcTrafficSpawner.chooseAction(this);
                if(this._isSpawning){
                    this._isSpawning = false; //End of spawn sequence
                    this.setSelfSwitch('A', true);
                }
            }
        }

        if(this._resetInteractionTimer > 0 && --this._resetInteractionTimer === 0 && this._resetInteraction) {
            this.setSelfSwitch(this._trafficInteract, false);
            this.clearInteractingNpc();
        }
    };

    // Modify the existing findDirectionTo method
    function customFindDirectionTo(goalX, goalY) {
        var searchLimit = this.searchLimit();
        var mapWidth = $gameMap.width();
        var nodeList = [];
        var openList = [];
        var closedList = [];
        var start = {};
        var best = start;

        if (this.x === goalX && this.y === goalY) {
            return 0;
        }

        start.parent = null;
        start.x = this.x;
        start.y = this.y;
        start.g = 0;
        start.w = 0;
        start.f = $gameMap.distance(start.x, start.y, goalX, goalY);
        nodeList.push(start);
        openList.push(start.y * mapWidth + start.x);

        while (nodeList.length > 0) {
            var bestIndex = 0;
            for (var i = 0; i < nodeList.length; i++) {
                if (nodeList[i].f < nodeList[bestIndex].f) {
                    bestIndex = i;
                }
            }

            var current = nodeList[bestIndex];
            var x1 = current.x;
            var y1 = current.y;
            var pos1 = y1 * mapWidth + x1;
            var g1 = current.g;

            nodeList.splice(bestIndex, 1);
            openList.splice(openList.indexOf(pos1), 1);
            closedList.push(pos1);

            if (current.x === goalX && current.y === goalY) {
                best = current;
                break;
            }

            if (g1 >= searchLimit) {
                continue;
            }

            for (var j = 0; j < 4; j++) {
                var direction = 2 + j * 2;
                var x2 = $gameMap.roundXWithDirection(x1, direction);
                var y2 = $gameMap.roundYWithDirection(y1, direction);
                var pos2 = y2 * mapWidth + x2;

                if (closedList.contains(pos2)) {
                    continue;
                }
                if (!this.canPass(x1, y1, direction)){
                    continue;
                }

                var g2 = g1 + 1;
                var index2 = openList.indexOf(pos2);

                if (index2 < 0 || g2 < nodeList[index2].g) {
                    var neighbor;
                    if (index2 >= 0) {
                        neighbor = nodeList[index2];
                    } else {
                        neighbor = {};
                        nodeList.push(neighbor);
                        openList.push(pos2);
                    }
                    neighbor.parent = current;
                    neighbor.x = x2;
                    neighbor.y = y2;
                    neighbor.g = g2;
                    neighbor.f = g2 + $gameMap.distance(x2, y2, goalX, goalY);
                    
                    // Adjust cost if the position is next to a wall - ignores wall tiles within 3 tiles of the destination
                    if (neighbor.f - g2 > 3 && this.isMapPassable(x2, y2, direction)) {
                        neighbor.f += this.isNextToWall(x2, y2, neighbor.f - g2); // Increase the cost slightly to avoid walls
                    }

                    if (!best || neighbor.f - neighbor.g < best.f - best.g) {
                        best = neighbor;
                    }
                }
            }
        }

        var node = best;
        while (node.parent && node.parent !== start) {
            node = node.parent;
        }

        var deltaX1 = $gameMap.deltaX(node.x, start.x);
        var deltaY1 = $gameMap.deltaY(node.y, start.y);
        if (deltaY1 > 0) {
            return 2;
        } else if (deltaX1 < 0) {
            return 4;
        } else if (deltaX1 > 0) {
            return 6;
        } else if (deltaY1 < 0) {
            return 8;
        }

        var deltaX2 = this.deltaXFrom(goalX);
        var deltaY2 = this.deltaYFrom(goalY);
        if (Math.abs(deltaX2) > Math.abs(deltaY2)) {
            return deltaX2 > 0 ? 4 : 6;
        } else if (deltaY2 !== 0) {
            return deltaY2 > 0 ? 8 : 2;
        }

        return 0;
    };

    Game_CharacterBase.prototype.isNextToWall = function(x, y, gDist) {
        let penalty = 0;
        const charx = this.x;
        const chary = this.y;
        let facex = x - charx;
        let facey = y - chary;

        let xArr = [];
        let yArr = [];

        if(facex != 0){
            facex = facex > 0 ? 1 : -1;
            xArr = xArr.concat([facex,facex,facex]);
            yArr = yArr.concat([0,1,-1]);
        }
        if(facey != 0){
            facey = facex > 0 ? 1 : -1;
            yArr = yArr.concat([facey,facey,facey]);
            xArr = xArr.concat([0,1,-1]);
        }
        
        for (let i = 0; i < xArr.length; i++) {
            const dx = xArr[i]; // Relative x offsets
            const dy = yArr[i]; // Relative y offsets
            const nx = x + dx;
            const ny = y + dy;

            if (!$gameMap.isPassable(nx, ny, 2) || !$gameMap.isPassable(nx, ny, 8) || !$gameMap.isPassable(nx, ny, 6) || !$gameMap.isPassable(nx, ny, 2)) {
                /*
                penalty += Math.round(gDist/2); // There is a obstacle near the tile
                if(nx === x + facex && ny === facey + y) {
                    penalty += Math.round(gDist/(xArr.length/3)); //Check if walking directly towards an obstacle and penalize
                } */
                penalty = 10;
            }
        }
        return penalty;
    };

    //Obsolete??
    Game_CharacterBase.prototype.updateNpcTimers = function () {
        if(this._resetInteractionTimer > 0) this._resetInteractionTimer--;
        if(this._actionTimer > 0) this._actionTimer--;
    }

    Game_CharacterBase.prototype.updateTargetObstructedCounter = function () {
        if(this.isMovementSucceeded()) {
            this._destinationObstructed = 0;
            return;
        }
        if(++this._destinationObstructed >= 180) {
            this._destinationObstructed = 0;
            Doommer.NpcTrafficSpawner.chooseAction(this);
        }
    }

    Game_Event.prototype.arrivedAtDestination = function() {
        if(this._leavingMap){
            this.useExit();
        } else {
            this.resolveDestinationAction();
            this._previousUsedEventId = this._target._eventId;
            this.clearTarget();
        }
    }

    Game_Event.prototype.resolveDestinationAction = function () {
        switch (this._target._actionType) {
            case "use":
                this.npcUse();
                this.setAsInteractingNpc();
                break;
            case "idle":
                this.npcIdle();
                this.setAsInteractingNpc();
                break;
            case "loiter":
                this.npcLoiter();
                break;
            default:
                this.setActionTimer(Math.getRandomBetween(this._maxTimeBetweenActions, this._minTimeBetweenActions));
                break;
        }
    }

    Game_Event.prototype.npcUse = function () {
        this._target.setSelfSwitch(this._target._trafficInteract, true);
        this._originalMoveType = this._moveType;
        this._moveType = 0;
        let time = 0;
        if(this._target._config && this._target._config.length == 2) {
           time = Math.getRandomBetween(...this._target._config);
        } else {
            time = Math.getRandomBetween(this._maxTimeBetweenActions, this._minTimeBetweenActions);
        }
        this.setActionTimer(time);
        this._target.setInteractionResetTimer(time);
    }
    Game_Event.prototype.npcIdle = function () {
        this._originalMoveType = this._moveType;
        this._moveType = 0;
        if(this._target._config && this._target._config.length == 2) {
            this.setActionTimer(Math.getRandomBetween(...this._target._config));
        } else {
            this.setActionTimer(Math.getRandomBetween(this._maxTimeBetweenActions, this._minTimeBetweenActions));
        }
    }
    Game_Event.prototype.npcLoiter = function () {
        if(Imported.Doommer_StayInArea){
            if(this._target._config && this._target._config.length >= 2) {
                this.setupApplyBoundaries(this._targetX, this._targetY, this._target._config[0], this._target._config[1]);
            } else {
                this.setupApplyBoundaries(this._targetX, this._targetY, ...this._target._config);
            }
        }
        if(this._target._config && this._target._config.length == 4) {
            this.setActionTimer(Math.getRandomBetween(this._target._config[2], this._target._config[3]));
        } else {
            this.setActionTimer(Math.getRandomBetween(this._maxTimeBetweenActions, this._minTimeBetweenActions));
        }
        this._originalMoveType = this._moveType;
        this._moveType = 1;
    }

    Game_Event.prototype.setAsInteractingNpc = function() {
        //Do not allow overriding in case an event is being procesed.
        if(this._isTraffic && this._target && this._target._interactingNpc == null) {
            this._target._interactingNpc = this._eventId;
        }
    }
    Game_Event.prototype.clearInteractingNpc = function() {
        if(this._target) {
            this._target._interactingNpc = null;
        }
        if(this._interactingNpc){
            this._interactingNpc = null;
        }
    }
    //ChangeExecutionContext.js plugin extension for autonomous npc interaction
    Game_Interpreter.prototype.asInteractingNpc = function(evalLines) {
        if(Imported.Doommer_ChangeExecutionContext) {
            let event = $gameMap.event(this._eventId);
            if(event && event._interactingNpc) {
                this.executeInContext(event._interactingNpc, evalLines);
            }
        }
    }

    //Does not support diagonal movement
    Game_CharacterBase.prototype.adjecentToTarget = function() {
        if(this._target == null){
            return false;
        }
        return Math.abs(this.x - this._targetX) + Math.abs(this.y - this._targetY) == 1;
    };

    Game_CharacterBase.prototype.isOnTarget = function () {
        if(this._target == null){
            return false;
        }
        return this._realX == this._targetX && this._realY == this._targetY;
    }

    Doommer_Game_Event_prototype_lock = Game_Event.prototype.lock;
    Game_Event.prototype.lock = function() {
        if(this._isTraffic && !this._lookAtPlayer) {
            if (!this._locked) {
                this._prelockDirection = this.direction();
                //this.turnTowardPlayer();
                this._locked = true;
            }
        } else {
            Doommer_Game_Event_prototype_lock.call(this);
        }
    };

    Doommer_Game_Event_prototype_chaseConditions = Game_Event.prototype.chaseConditions;
    Game_Event.prototype.chaseConditions = function(dis) {
        if(Doommer_Game_Event_prototype_chaseConditions.call(this, dis)) {
            //Suspend Action
            if(this._target) {
                this._previousTarget = this._target;
            }
            if(this._anchorCoord){
                this.suspendZoneRestriction();
            }
            this.clearTarget();
            return true;
        }
        return false;
    };

    Game_Event.prototype.setSelfSwitch = function(selfSwitch,value = false) {
        let key = $gameMap._mapId + "," + this._eventId + "," + selfSwitch;
        $gameSelfSwitches.setValue(key,value);
    };

    Doommer_Game_Event_prototype_startReturnPhase = Game_Event.prototype.startReturnPhase;
    Game_Event.prototype.startReturnPhase = function() {
        if (!this._returnAfter) {
            this.requestBalloon(2);
            if(this._isTraffic && this._previousTarget) this.setTarget(this._previousTarget);
            if(this._anchorCoord) this.reinstateZoneRestriction();
        } else {
            this._returnPhase = true;
            this._returnFrames = this._returnWait;
        }
    };

    Doommer_Game_Event_prototype_updateMoveReturnAfter = Game_Event.prototype.updateMoveReturnAfter;
    Game_Event.prototype.updateMoveReturnAfter = function() {
        if (this._returnFrames > 0) {
            this.requestBalloon(2);
            this.moveRandom();
            return;
        }
        var sx = this.deltaXFrom(this._startLocationX);
        var sy = this.deltaYFrom(this._startLocationY);
        if (Math.abs(sx) > Math.abs(sy)) {
          if (Math.randomInt(6) <= 4) {
            this.moveStraight(sx > 0 ? 4 : 6);
            if (!this.isMovementSucceeded() && sy !== 0) {
              this.moveStraight(sy > 0 ? 8 : 2);
            }
          } else {
            this.moveRandom();
          }
        } else if (sy !== 0) {
          if (Math.randomInt(6) <= 4) {
            this.moveStraight(sy > 0 ? 8 : 2);
            if (!this.isMovementSucceeded() && sx !== 0) {
              this.moveStraight(sx > 0 ? 4 : 6);
            }
          } else {
            this.moveRandom();
          }
        }
        if (sx === 0 && sy === 0) {
          this._returnPhase = false;
          this._returnFrames = 0;
          this._direction = this._startLocationDir;
          //Continue previous task
          if(this._isTraffic && this._previousTarget) {
            this.setTarget(this._previousTarget);
          }
        }
    };

    Game_Event.prototype.getVisibleEvents = function(events){
        let valid = [];

        Object.values(events).forEach((e) => {
            if (e.visibleTo && !e.visibleTo.some(id => this._spawnEventId == id)) {
                return;
            }
            valid.push(e);
        });
        return valid;
    }

    //Auto spawn
    Doommer_Game_Map_prototype_update = Game_Map.prototype.update;
    Game_Map.prototype.update = function(sceneActive) {
        Doommer_Game_Map_prototype_update.call(this, sceneActive);
        if(this._allowSpawn && this.spawnedEvents().filter(se => se._isTraffic).length < this._npcLimit) {
            //Only update timer if spawn condition are valid
            this._timeSinceLastSpawn++;
        }
        if (this._allowedNpcs) {
            for (let npc in this._allowedNpcs) {
                if (this._allowedNpcs[npc].spawnCooldown > 0) {
                    // Using the -- operator to decrement spawnTimeCounter
                    this._allowedNpcs[npc].spawnCooldown--;
                }
            }
        }
    };

    Doommer.NpcTrafficSpawner.resetTimer = function () {
        $gameMap._timeSinceLastSpawn = 0;
    }

    Doommer.NpcTrafficSpawner.autoSpawner = function (frequency=1, interval = undefined) {
        if($gameMap._interpreter.isRunning()) return;

        if(Doommer.NpcTrafficSpawner.shouldSpawn(frequency, interval))
            {
            eventToSpawn = Doommer.NpcTrafficSpawner.getRandomValidNpc();
            if(eventToSpawn) {
                if(eventToSpawn.useConsistentSpawn) {
                    Doommer.NpcTrafficSpawner.spawn(eventToSpawn.npcId, eventToSpawn._previousUsedEventId);
                } else {
                    Doommer.NpcTrafficSpawner.spawn(eventToSpawn.npcId);
                }
                Doommer.NpcTrafficSpawner.resetTimer();
            }
        }
    }

    Doommer.NpcTrafficSpawner.shouldSpawn = function(frequency, interval) {
        return $gameMap._allowSpawn && $gameMap._timeSinceLastSpawn / frequency > (interval || Doommer.Param.npcMinSpawnTime);
    };

    Doommer.NpcTrafficSpawner.getRandomValidNpc = function () {
        let npcs = Doommer.NpcTrafficSpawner.getValidNpcs();
        
        let cumulativeWeight = 0;
        let weightedList = npcs.map(npc => {
            cumulativeWeight += npc.autoSpawnWeight || 1;
            return { npc, cumulativeWeight };
        });
        const randomWeight = Math.random() * cumulativeWeight;

        const res = weightedList.find(entry => entry.cumulativeWeight >= randomWeight);
        return res !== undefined ? res.npc : null;
    }
 
    Doommer.NpcTrafficSpawner.getValidNpcs = function () {
        let valid = [];

        Object.values($gameMap._allowedNpcs).forEach((npc) => {
        if (npc.spawnCooldown <= 0 && (npc.active < 1 || (!$gameMap._uniqueSpawns && (npc.limit === -1 || npc.active < npc.limit)))) {
            valid.push(npc);
        }
        });
        return valid;
    }

    Doommer_Game_Map_prototype_setup = Game_Map.prototype.setup;
    Game_Map.prototype.setup = function (mapId) {
        Doommer_Game_Map_prototype_setup.call(this, mapId);

        this._allowedNpcs = {};
        this._spawners = {};
        this._despawners = {};
        this._pointsOfInterests = {};
        this._timeSinceLastSpawn = 0;
        this._allowSpawn = false;
        this._npcLimit = Doommer.Param.npcMaxTraffic;
        this._uniqueSpawns = Doommer.Param.npcUniqueSpawns;
        this._npcExitPercentage = Doommer.Param.npcExitPercentage / 100;
    }

    //Maths
    function getRandomObjectEntry(object) {
        const keys = Object.keys(object);

        const randomIndex = Math.getRandomBetween(keys.length);

        const randomKey = keys[randomIndex];

        return object[randomKey];
    }
    function getRandomArrayEntry(array) {
        const randomIndex = Math.getRandomBetween(array.length);

        return array[randomIndex];
    }
    Math.getRandomBetween = function (max, min = 0) {
        return Math.floor(Math.random() * (max - min) + min);
    }

})();