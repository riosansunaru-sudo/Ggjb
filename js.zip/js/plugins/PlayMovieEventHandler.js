/*:
 * @plugindesc Removes an unnecassary .load() call from the base engine 'Play Movie' command and uses htmlVideoElement events to determine video state and playback readiness. Also clear the channel for the next movei played to prevent overlap.
 * @author Doommer
 *
 * @help This plugin checks and resumes video playback if it gets stuck.
 * There are no plugin commands or parameters for this plugin.
 */

(function() {
    //var checkInterval = 500; // Interval to check the video status (in milliseconds)

    var originalOnVideoLoad = Graphics._onVideoLoad;
    Graphics._onVideoLoad = function() {
        const video = Graphics._video;
        console.log(video);
        const videoDetails = {
            src: video.src,
            currentTime: video.currentTime,
            duration: video.duration,
            paused: video.paused,
            ended: video.ended,
            readyState: video.readyState,
            networkState: video.networkState,
            volume: video.volume,
            muted: video.muted,
            playbackRate: video.playbackRate,
            bufferedRanges: {start: video.buffered.start(0), end: video.buffered.end(0)},
            videoWidth: video.videoWidth,
            videoHeight: video.videoHeight,
            error: video.error ? { code: video.error.code, message: video.error.message } : null
        };
    
        console.log("Video Element Details:", JSON.parse(JSON.stringify(videoDetails)));

        if (video.readyState < 4 || video.paused) {
            // Wait for the video to be fully loaded
            video.oncanplaythrough = function() {
                video.oncanplaythrough = null; // Remove the event listener
                video.play();
                originalOnVideoLoad.call(Graphics); // Call the original _onVideoLoad method
            };
            video.load(); // Ensure the video is loading
        } else {
            // If readyState is already 4, call the original method directly
            originalOnVideoLoad.call(Graphics);
        }
    };

    var original_playVideo = Graphics._playVideo;
    Graphics._playVideo = function(src) {
        console.log("Custom intialization");
        const video = Graphics._video;
        const videoDetails = {
            src: video.src,
            currentTime: video.currentTime,
            duration: video.duration,
            paused: video.paused,
            ended: video.ended,
            readyState: video.readyState,
            networkState: video.networkState,
            volume: video.volume,
            muted: video.muted,
            playbackRate: video.playbackRate,
            videoWidth: video.videoWidth,
            videoHeight: video.videoHeight,
            error: video.error ? { code: video.error.code, message: video.error.message } : null
        };
    
        console.log("Video Element Details:", JSON.parse(JSON.stringify(videoDetails)));
        video.oncanplaythrough = function() {
            video.oncanplaythrough = null; // Remove the event listener
            video.paued = false;
            Graphics._onVideoLoad.call(Graphics); // Call the original _onVideoLoad method
        };
        video.src = src;
        video.onloadeddata = null;//this._onVideoLoad.bind(this);
        video.onerror = Graphics._videoLoader;
        video.onended = Graphics._onVideoEnd.bind(this);
        //video.load();
        video.autoplay = true;
        Graphics._videoLoading = true;
    }

    var originalonvideoend = Graphics._onVideoEnd;
    Graphics._onVideoEnd = function () {
        const video = Graphics._video;
        originalonvideoend.call(Graphics);
        video.removeAttribute('src');
        video.load();
    }
})();