Theo.Shake.spritesetBattle_updatePos = Spriteset_Battle.prototype.updatePosition;
Spriteset_Battle.prototype.updatePosition = function(){
    Theo.Shake.spritesetBattle_updatePos.call(this);
    if($gameTemp.shake_dur > 0){
        $gameTemp.shake_dur -= 1;
        let rate = $gameTemp.shake_dur/$gameTemp.shake_maxdur;
        this.x += Math.random() * $gameTemp.shake_pow * rate * (Math.random() >= 0.5 ? 1 : -1);
        this.y += Math.random() * $gameTemp.shake_pow * rate * (Math.random() >= 0.5 ? 1 : -1);
    }
}