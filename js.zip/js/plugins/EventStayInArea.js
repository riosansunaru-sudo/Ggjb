/*:
 * @plugindesc Designates an area inwhich npcs may wander about
 * @author Doommer
 *
 * @help
 */

var Imported = Imported || {};
Imported.Doommer_StayInArea = true;

var Doommer = Doommer || {};
Doommer.StayInArea = Doommer.StayInArea || {};

(function() {

    Game_Event.prototype.setupSelfBoundaries = function (distX, distY=distX) {
        this.setupApplyBoundaries(this.x, this.y, distX, distY);
    }

    Game_Event.prototype.setupApplyBoundaries = function (startX, startY, distX, distY=distX) {
        if(distX === 0 && distY === 0) return;
        this._anchorCoord = { x: startX, y: startY};
        this._maxX = Math.abs(distX);
        this._maxY = Math.abs(distY);
    }

    Game_Event.prototype.removeBoundary = function () {
        this._anchorCoord = null;
        this._maxX = null;
        this._maxY = null;
    }

    Game_Event.prototype.isOutsideDesignatedZone = function () {
        if(!this._anchorCoord) return false;
        if(Math.abs(this.x - this._anchorCoord.x) > this._maxX) return true;
        if(Math.abs(this.y - this._anchorCoord.y) > this._maxY) return true;
    };
    Game_CharacterBase.prototype.goBackToZone = function () {
        this.suspendZoneRestriction();
        let d = this.findDirectionTo(this._anchorCoord.x, this._anchorCoord.y);
        this.moveStraight(d);
        this.reinstateZoneRestriction();
    }

    Doommer.StayInArea.Game_Event_prototype_updateSelfMovement =
    Game_Event.prototype.updateSelfMovement;
    Game_Event.prototype.updateSelfMovement = function() {
        Doommer.StayInArea.Game_Event_prototype_updateSelfMovement.call(this);
        if(this.isOutsideDesignatedZone() && !this._suspendZone && this._anchorCoord){
            this.goBackToZone();
        }
    };

    Doommer.StayInArea.Game_CharacterBase_isMapPassable =
    Game_CharacterBase.prototype.isMapPassable;
    Game_CharacterBase.prototype.isMapPassable = function(x, y, d) {
        if (this.isTileOutsideDesignatedZone(x, y, d)) return false;
        return Doommer.StayInArea.Game_CharacterBase_isMapPassable.call(this, x, y, d);
    };

    Game_CharacterBase.prototype.isTileOutsideDesignatedZone = function(x, y, d) {
        if (this.isPlayer()) return false;
        if(this.isEvent() && this._anchorCoord && !this._suspendZone){
            var x2 = $gameMap.roundXWithDirection(x, d);
            var y2 = $gameMap.roundYWithDirection(y, d);
            return Math.abs(x2 - this._anchorCoord.x) > this._maxX
            || Math.abs(y2 - this._anchorCoord.y) > this._maxY;
        }
        return false;
    };

    Game_CharacterBase.prototype.suspendZoneRestriction = function(){
        this._suspendZone = true;
    };
    Game_CharacterBase.prototype.reinstateZoneRestriction = function(){
        this._suspendZone = false;
    };

    Game_CharacterBase.prototype.isEvent = function() {
        return false;
    };
    Game_CharacterBase.prototype.isPlayer = function() {
        return false;
    };

    Game_Event.prototype.isEvent = function() {
        return true;
    };

    Game_Player.prototype.isPlayer = function() {
        return true;
    };
    
})();