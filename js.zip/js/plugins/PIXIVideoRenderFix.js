/*:
 * @plugindesc Modifies Pixi.js v4.5.4 to avoid using texSubImage2D() to render videos.
 * @author Doommer
 *
 * @help Should be a simply but significant performance increase when playing videos.
 * There are no plugin commands or parameters for this plugin.
 */
(function() {
    // Check if PIXI and glCore exist in the current environment
    if (!PIXI || PIXI.VERSION != "4.5.4" || !PIXI.glCore || !PIXI.glCore.GLTexture) {
        console.error("PIXI version '4.5.4' or PIXI.glCore.GLTexture is not available in this environment.");
        return;
    }

    // Override the upload method
    PIXI.glCore.GLTexture.prototype.upload = function(source) {
        this.bind();

        var gl = this.gl;

        // Set the premultiply alpha pixel store state
        gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, this.premultiplyAlpha);

        // Determine if the source is a video
        var isVideo = !!source.videoWidth;
        var newWidth = isVideo ? source.videoWidth : source.width;
        var newHeight = isVideo ? source.videoHeight : source.height;

        // Check if the texture size has changed or if the source is a video
        if (newHeight !== this.height || newWidth !== this.width || isVideo) {
            // Upload the entire texture data
            gl.texImage2D(gl.TEXTURE_2D, 0, this.format, this.format, this.type, source);
        } else {
            // Update a sub-region of the texture data
            gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, this.format, this.type, source);
        }

        // Update the texture's width and height
        this.width = newWidth;
        this.height = newHeight;
    };
})();